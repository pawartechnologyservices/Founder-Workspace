
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { NotificationProvider } from './contexts/NotificationContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from './components/ui/toaster';
import { Toaster as SonnerToaster } from './components/ui/sonner';

// Layout and Auth Components
import DashboardLayout from './components/Layout/DashboardLayout';
import LoginPage from './components/auth/LoginPage';

// Pages
import Dashboard from './pages/Dashboard';
import Patients from './pages/Patients';
import Appointments from './pages/Appointments';
import Billing from './pages/Billing';
import Inventory from './pages/Inventory';
import Reports from './pages/Reports';
import Emergency from './pages/Emergency';
import Settings from './pages/Settings';
import NotFound from './pages/NotFound';
import Index from './pages/Index';

// Mock inventory data for notifications
const mockInventoryData = [
  {
    id: '1',
    name: 'Dental Floss',
    category: 'supplies' as const,
    currentStock: 5,
    minStock: 20,
    maxStock: 100,
    unit: 'pcs',
    costPerUnit: 25,
    supplier: 'MedSupply Co.',
    expiryDate: new Date('2024-12-31'),
    lastRestocked: new Date('2024-01-10'),
    status: 'low_stock' as const
  },
  {
    id: '4',
    name: 'Disposable Gloves',
    category: 'supplies' as const,
    currentStock: 0,
    minStock: 50,
    maxStock: 200,
    unit: 'boxes',
    costPerUnit: 12,
    supplier: 'SafetyFirst Inc.',
    expiryDate: new Date('2025-01-31'),
    lastRestocked: new Date('2023-12-20'),
    status: 'out_of_stock' as const
  },
];

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <NotificationProvider inventoryItems={mockInventoryData}>
            <Router>
              <div className="min-h-screen bg-background">
                <Routes>
                  <Route path="/" element={<Index />} />
                  <Route path="/login" element={<LoginPage />} />
                  <Route path="/dashboard" element={<DashboardLayout />}>
                    <Route index element={<Dashboard />} />
                    <Route path="patients" element={<Patients />} />
                    <Route path="appointments" element={<Appointments />} />
                    <Route path="billing" element={<Billing />} />
                    <Route path="inventory" element={<Inventory />} />
                    <Route path="reports" element={<Reports />} />
                    <Route path="emergency" element={<Emergency />} />
                    <Route path="settings" element={<Settings />} />
                  </Route>
                  <Route path="/patients" element={<Navigate to="/dashboard/patients" replace />} />
                  <Route path="/appointments" element={<Navigate to="/dashboard/appointments" replace />} />
                  <Route path="/billing" element={<Navigate to="/dashboard/billing" replace />} />
                  <Route path="/inventory" element={<Navigate to="/dashboard/inventory" replace />} />
                  <Route path="/reports" element={<Navigate to="/dashboard/reports" replace />} />
                  <Route path="/emergency" element={<Navigate to="/dashboard/emergency" replace />} />
                  <Route path="/settings" element={<Navigate to="/dashboard/settings" replace />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
                <Toaster />
                <SonnerToaster />
              </div>
            </Router>
          </NotificationProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
