
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useIsMobile } from '@/hooks/use-mobile';
import {
  Users,
  Calendar,
  FileText,
  CreditCard,
  Package,
  Activity,
  BarChart3,
  Phone,
  Settings,
  LogOut,
  Hospital
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const Sidebar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const menuItems = [
    { 
      icon: BarChart3, 
      label: 'Dashboard', 
      path: '/dashboard',
      description: 'Overview & Analytics'
    },
    { 
      icon: Users, 
      label: 'Patient Management', 
      path: '/patients',
      description: 'Add, View & Manage Patients'
    },
    { 
      icon: Calendar, 
      label: 'Appointment Management', 
      path: '/appointments',
      description: 'Schedule & Track Appointments'
    },
    { 
      icon: CreditCard, 
      label: 'Billing & Invoice', 
      path: '/billing',
      description: 'Generate Bills & Invoices'
    },
    { 
      icon: Package, 
      label: 'Inventory Management', 
      path: '/inventory',
      description: 'Track Supplies & Stock'
    },
    { 
      icon: FileText, 
      label: 'Reports', 
      path: '/reports',
      description: 'Analytics & Data Export'
    },
    { 
      icon: Phone, 
      label: 'Emergency', 
      path: '/emergency',
      description: 'Emergency Contacts & Support'
    },
    { 
      icon: Settings, 
      label: 'Settings', 
      path: '/settings',
      description: 'System Configuration'
    }
  ];

  return (
    <div className="w-64 bg-sidebar border-r border-sidebar-border h-full flex flex-col shadow-lg">
      {/* Logo/Header */}
      <div className="p-6 sm:p-8 border-b border-sidebar-border bg-gradient-to-r from-sidebar to-sidebar-accent">
        <div className="flex items-center justify-center">
          <img 
            src="/lovable-uploads/b268d5a3-1083-453a-981b-5b34f02cb606.png" 
            alt="Dr. Sneha's Dental Lounge" 
            className="h-16 w-auto sm:h-20 object-contain" 
          />
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 sm:p-4 overflow-y-auto">
        <h3 className="text-xs font-semibold text-sidebar-foreground/70 uppercase tracking-wide mb-3">
          Main Menu
        </h3>
        <ul className="space-y-1">
          {menuItems.map((item) => (
            <li key={item.path}>
              <NavLink
                to={item.path}
                className={({ isActive }) =>
                  `flex items-start space-x-3 px-3 py-3 rounded-lg transition-all duration-200 group touch-target ${
                    isActive
                      ? 'bg-gradient-to-r from-amber-400/20 to-amber-600/20 text-amber-600 border-r-2 border-amber-600 shadow-md'
                      : 'text-sidebar-foreground hover:bg-gradient-to-r hover:from-amber-400/10 hover:to-amber-600/10 hover:text-amber-600 hover:shadow-sm'
                  }`
                }
              >
                <item.icon className="h-4 w-4 sm:h-5 sm:w-5 mt-0.5 flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <span className="font-medium text-xs sm:text-sm block truncate">{item.label}</span>
                  {!isMobile && (
                    <p className="text-xs text-sidebar-foreground/50 mt-0.5 line-clamp-2">{item.description}</p>
                  )}
                </div>
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      {/* System Status */}
      <div className="p-3 sm:p-4 border-t border-sidebar-border bg-sidebar-accent/30">
        <div className="flex items-center justify-between text-xs text-sidebar-foreground/60 mb-2">
          <span>System Status</span>
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span>Online</span>
          </div>
        </div>
        {!isMobile && (
          <div className="flex items-center justify-between text-xs text-sidebar-foreground/60">
            <span>Last Backup</span>
            <span>{new Date().toLocaleDateString()}</span>
          </div>
        )}
      </div>

      {/* Logout */}
      <div className="p-3 sm:p-4 border-t border-sidebar-border">
        <Button
          onClick={handleLogout}
          variant="ghost"
          className="w-full justify-start space-x-3 text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all duration-200 touch-target"
        >
          <LogOut className="h-4 w-4" />
          <span className="text-xs sm:text-sm">Logout</span>
        </Button>
      </div>
    </div>
  );
};

export default Sidebar;
