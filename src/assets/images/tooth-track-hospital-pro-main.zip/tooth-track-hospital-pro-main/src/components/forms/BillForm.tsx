
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { X, Plus, Minus } from 'lucide-react';
import { Bill } from '@/types';

interface BillFormProps {
  onClose: () => void;
  onSubmit: (bill: Omit<Bill, 'id' | 'createdAt'>) => void;
  bill?: Bill;
  isEdit?: boolean;
  patients: Array<{ id: string; name: string; phone: string }>;
}

interface TreatmentItem {
  id: string;
  name: string;
  cost: number;
  quantity: number;
}

const BillForm = ({ onClose, onSubmit, bill, isEdit = false, patients }: BillFormProps) => {
  const [formData, setFormData] = useState({
    patientId: bill?.patientId || '',
    patientName: bill?.patientName || '',
    dueDate: bill?.dueDate ? new Date(bill.dueDate).toISOString().split('T')[0] : '',
    discount: bill?.discount || 0,
    tax: bill?.tax || 18,
    status: bill?.status || 'pending' as 'pending' | 'paid' | 'partially_paid' | 'overdue',
    paymentMethod: bill?.paymentMethod || undefined as 'cash' | 'card' | 'upi' | 'insurance' | undefined,
    paidAmount: bill?.paidAmount || 0
  });

  const [treatments, setTreatments] = useState<TreatmentItem[]>([
    { id: '1', name: '', cost: 0, quantity: 1 }
  ]);

  const [errors, setErrors] = useState<Record<string, string>>({});

  const treatmentOptions = [
    { name: 'Dental Checkup', cost: 500 },
    { name: 'Teeth Cleaning', cost: 1000 },
    { name: 'Root Canal', cost: 5000 },
    { name: 'Tooth Extraction', cost: 1500 },
    { name: 'Dental Filling', cost: 800 },
    { name: 'Crown Placement', cost: 3000 },
    { name: 'Braces Installation', cost: 15000 },
    { name: 'Teeth Whitening', cost: 2000 },
    { name: 'Wisdom Tooth Removal', cost: 3500 },
    { name: 'Dental Implant', cost: 25000 }
  ];

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.patientId) newErrors.patientId = 'Please select a patient';
    if (!formData.dueDate) newErrors.dueDate = 'Due date is required';
    
    const hasValidTreatment = treatments.some(t => t.name && t.cost > 0);
    if (!hasValidTreatment) newErrors.treatments = 'At least one treatment is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const calculateSubtotal = () => {
    return treatments.reduce((sum, treatment) => sum + (treatment.cost * treatment.quantity), 0);
  };

  const calculateTotal = () => {
    const subtotal = calculateSubtotal();
    const taxAmount = (subtotal * formData.tax) / 100;
    return subtotal + taxAmount - formData.discount;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    const subtotal = calculateSubtotal();
    const total = calculateTotal();
    const taxAmount = (subtotal * formData.tax) / 100;

    const billData = {
      ...formData,
      treatments: [], // In real app, this would be treatment objects
      subtotal,
      tax: taxAmount,
      total,
      dueDate: new Date(formData.dueDate)
    };

    onSubmit(billData);
  };

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handlePatientSelect = (patientId: string) => {
    const selectedPatient = patients.find(p => p.id === patientId);
    setFormData(prev => ({
      ...prev,
      patientId,
      patientName: selectedPatient?.name || ''
    }));
    if (errors.patientId) {
      setErrors(prev => ({ ...prev, patientId: '' }));
    }
  };

  const addTreatment = () => {
    setTreatments(prev => [...prev, { id: Date.now().toString(), name: '', cost: 0, quantity: 1 }]);
  };

  const removeTreatment = (id: string) => {
    if (treatments.length > 1) {
      setTreatments(prev => prev.filter(t => t.id !== id));
    }
  };

  const updateTreatment = (id: string, field: string, value: string | number) => {
    setTreatments(prev => prev.map(t => 
      t.id === id ? { ...t, [field]: value } : t
    ));
  };

  const handleTreatmentSelect = (id: string, treatmentName: string) => {
    const selectedTreatment = treatmentOptions.find(t => t.name === treatmentName);
    if (selectedTreatment) {
      setTreatments(prev => prev.map(t => 
        t.id === id ? { ...t, name: treatmentName, cost: selectedTreatment.cost } : t
      ));
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>{isEdit ? 'Edit Bill' : 'Generate New Bill'}</CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="patient">Patient *</Label>
                <Select value={formData.patientId} onValueChange={handlePatientSelect}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select patient" />
                  </SelectTrigger>
                  <SelectContent>
                    {patients.map((patient) => (
                      <SelectItem key={patient.id} value={patient.id}>
                        {patient.name} - {patient.phone}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.patientId && <p className="text-sm text-red-500">{errors.patientId}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="dueDate">Due Date *</Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => handleInputChange('dueDate', e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                />
                {errors.dueDate && <p className="text-sm text-red-500">{errors.dueDate}</p>}
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Treatments *</Label>
                <Button type="button" onClick={addTreatment} size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Treatment
                </Button>
              </div>
              
              {treatments.map((treatment, index) => (
                <div key={treatment.id} className="grid grid-cols-12 gap-4 items-end">
                  <div className="col-span-5">
                    <Label>Treatment</Label>
                    <Select value={treatment.name} onValueChange={(value) => handleTreatmentSelect(treatment.id, value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select treatment" />
                      </SelectTrigger>
                      <SelectContent>
                        {treatmentOptions.map((option) => (
                          <SelectItem key={option.name} value={option.name}>
                            {option.name} - ₹{option.cost}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="col-span-2">
                    <Label>Quantity</Label>
                    <Input
                      type="number"
                      min="1"
                      value={treatment.quantity}
                      onChange={(e) => updateTreatment(treatment.id, 'quantity', parseInt(e.target.value))}
                    />
                  </div>
                  
                  <div className="col-span-3">
                    <Label>Cost per unit</Label>
                    <Input
                      type="number"
                      value={treatment.cost}
                      onChange={(e) => updateTreatment(treatment.id, 'cost', parseFloat(e.target.value))}
                    />
                  </div>
                  
                  <div className="col-span-1">
                    <Label>Total</Label>
                    <p className="text-sm font-medium">₹{treatment.cost * treatment.quantity}</p>
                  </div>
                  
                  <div className="col-span-1">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removeTreatment(treatment.id)}
                      disabled={treatments.length === 1}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              {errors.treatments && <p className="text-sm text-red-500">{errors.treatments}</p>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tax">Tax (%)</Label>
                <Input
                  id="tax"
                  type="number"
                  value={formData.tax}
                  onChange={(e) => handleInputChange('tax', parseFloat(e.target.value))}
                  min="0"
                  max="100"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="discount">Discount (₹)</Label>
                <Input
                  id="discount"
                  type="number"
                  value={formData.discount}
                  onChange={(e) => handleInputChange('discount', parseFloat(e.target.value))}
                  min="0"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="paymentMethod">Payment Method</Label>
                <Select value={formData.paymentMethod || ''} onValueChange={(value) => handleInputChange('paymentMethod', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">Cash</SelectItem>
                    <SelectItem value="card">Card</SelectItem>
                    <SelectItem value="upi">UPI</SelectItem>
                    <SelectItem value="insurance">Insurance</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg space-y-2">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>₹{calculateSubtotal()}</span>
              </div>
              <div className="flex justify-between">
                <span>Tax ({formData.tax}%):</span>
                <span>₹{((calculateSubtotal() * formData.tax) / 100).toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Discount:</span>
                <span>-₹{formData.discount}</span>
              </div>
              <hr />
              <div className="flex justify-between font-bold text-lg">
                <span>Total:</span>
                <span>₹{calculateTotal().toFixed(2)}</span>
              </div>
            </div>

            <div className="flex justify-end space-x-4">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit">
                {isEdit ? 'Update Bill' : 'Generate Bill'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default BillForm;
