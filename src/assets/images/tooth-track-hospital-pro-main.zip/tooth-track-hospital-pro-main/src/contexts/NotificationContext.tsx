
import React, { createContext, useContext, useState, useEffect } from 'react';
import { InventoryItem } from '@/types';

interface Notification {
  id: string;
  type: 'low_stock' | 'expired' | 'info' | 'success' | 'warning';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  itemId?: string;
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  removeNotification: (id: string) => void;
  clearAll: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

interface NotificationProviderProps {
  children: React.ReactNode;
  inventoryItems: InventoryItem[];
}

export const NotificationProvider: React.FC<NotificationProviderProps> = ({ children, inventoryItems }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const addNotification = (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
    const newNotification: Notification = {
      ...notification,
      id: Date.now().toString(),
      timestamp: new Date(),
      read: false,
    };
    setNotifications(prev => [newNotification, ...prev]);
  };

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(notif => notif.id === id ? { ...notif, read: true } : notif)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(notif => ({ ...notif, read: true })));
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(notif => notif.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  // Check for low stock and expired items
  useEffect(() => {
    const checkInventoryAlerts = () => {
      inventoryItems.forEach(item => {
        // Check for low stock
        if (item.currentStock <= item.minStock && item.currentStock > 0) {
          const existingLowStock = notifications.find(n => 
            n.type === 'low_stock' && n.itemId === item.id
          );
          
          if (!existingLowStock) {
            addNotification({
              type: 'low_stock',
              title: 'Low Stock Alert',
              message: `${item.name} is running low (${item.currentStock}/${item.minStock})`,
              itemId: item.id,
            });
          }
        }

        // Check for out of stock
        if (item.currentStock === 0) {
          const existingOutOfStock = notifications.find(n => 
            n.type === 'warning' && n.itemId === item.id
          );
          
          if (!existingOutOfStock) {
            addNotification({
              type: 'warning',
              title: 'Out of Stock',
              message: `${item.name} is out of stock`,
              itemId: item.id,
            });
          }
        }

        // Check for expired items
        if (item.expiryDate && new Date(item.expiryDate) < new Date()) {
          const existingExpired = notifications.find(n => 
            n.type === 'expired' && n.itemId === item.id
          );
          
          if (!existingExpired) {
            addNotification({
              type: 'expired',
              title: 'Expired Item',
              message: `${item.name} has expired`,
              itemId: item.id,
            });
          }
        }
      });
    };

    checkInventoryAlerts();
  }, [inventoryItems]);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        addNotification,
        markAsRead,
        markAllAsRead,
        removeNotification,
        clearAll,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};
