
import React, { useState } from 'react';
import { CreditCard, Search, Download, Eye, DollarSign, AlertCircle, CheckCircle, Plus, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import BillForm from '@/components/forms/BillForm';
import { Bill, Patient } from '@/types';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { useToast } from '@/hooks/use-toast';

const Billing = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [editingBill, setEditingBill] = useState<Bill | null>(null);
  const [bills, setBills] = useLocalStorage<Bill[]>('bills', []);
  const [patients] = useLocalStorage<Patient[]>('patients', []);
  const { toast } = useToast();

  const filteredBills = bills.filter(bill => {
    const matchesSearch = bill.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         bill.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || bill.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'partially_paid':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'pending':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      case 'overdue':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid':
        return <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />;
      case 'partially_paid':
        return <AlertCircle className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />;
      case 'pending':
        return <AlertCircle className="h-4 w-4 text-red-600 dark:text-red-400" />;
      case 'overdue':
        return <AlertCircle className="h-4 w-4 text-red-600 dark:text-red-400" />;
      default:
        return <DollarSign className="h-4 w-4 text-gray-600 dark:text-gray-400" />;
    }
  };

  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString()}`;
  };

  const handleAddBill = (billData: Omit<Bill, 'id' | 'createdAt'>) => {
    const newBill: Bill = {
      ...billData,
      id: `INV-${Date.now()}`,
      createdAt: new Date()
    };
    
    setBills(prev => [...prev, newBill]);
    setShowForm(false);
    toast({
      title: "Success",
      description: "Bill generated successfully",
    });
  };

  const handleEditBill = (billData: Omit<Bill, 'id' | 'createdAt'>) => {
    if (!editingBill) return;
    
    const updatedBill: Bill = {
      ...billData,
      id: editingBill.id,
      createdAt: editingBill.createdAt
    };
    
    setBills(prev => prev.map(b => b.id === editingBill.id ? updatedBill : b));
    setEditingBill(null);
    toast({
      title: "Success",
      description: "Bill updated successfully",
    });
  };

  const handleDeleteBill = (billId: string) => {
    if (confirm('Are you sure you want to delete this bill?')) {
      setBills(prev => prev.filter(b => b.id !== billId));
      toast({
        title: "Success",
        description: "Bill deleted successfully",
      });
    }
  };

  const handlePaymentUpdate = (billId: string, paidAmount: number) => {
    setBills(prev => prev.map(bill => {
      if (bill.id === billId) {
        const newPaidAmount = bill.paidAmount + paidAmount;
        let newStatus: Bill['status'] = 'pending';
        
        if (newPaidAmount >= bill.total) {
          newStatus = 'paid';
        } else if (newPaidAmount > 0) {
          newStatus = 'partially_paid';
        }
        
        return { ...bill, paidAmount: newPaidAmount, status: newStatus };
      }
      return bill;
    }));
    
    toast({
      title: "Success",
      description: "Payment updated successfully",
    });
  };

  const generateInvoicePDF = (bill: Bill) => {
    // In a real app, this would generate and download a PDF
    const content = `
DENTAL HOSPITAL INVOICE
------------------------
Invoice ID: ${bill.id}
Patient: ${bill.patientName}
Date: ${new Date(bill.createdAt).toLocaleDateString()}
Due Date: ${new Date(bill.dueDate).toLocaleDateString()}

Subtotal: ${formatCurrency(bill.subtotal)}
Tax: ${formatCurrency(bill.tax)}
Discount: ${formatCurrency(bill.discount)}
------------------------
Total: ${formatCurrency(bill.total)}
Paid: ${formatCurrency(bill.paidAmount)}
Due: ${formatCurrency(bill.total - bill.paidAmount)}
Status: ${bill.status.toUpperCase()}
    `;
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Invoice-${bill.id}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Success",
      description: "Invoice downloaded successfully",
    });
  };

  const totalRevenue = bills.reduce((sum, bill) => sum + bill.paidAmount, 0);
  const pendingAmount = bills.reduce((sum, bill) => sum + (bill.total - bill.paidAmount), 0);
  const paidBills = bills.filter(b => b.status === 'paid').length;
  const pendingBills = bills.filter(b => b.status === 'pending' || b.status === 'partially_paid').length;

  return (
    <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-gray-100">Billing & Payments</h1>
          <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">Manage patient bills and payment tracking</p>
        </div>
        <Button 
          className="flex items-center justify-center space-x-2 w-full sm:w-auto touch-target" 
          onClick={() => setShowForm(true)}
        >
          <CreditCard className="h-4 w-4" />
          <span>Generate New Bill</span>
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-4 sm:p-6">
            <div className="space-y-2">
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Total Revenue</p>
              <p className="text-xl sm:text-2xl font-bold text-green-600">{formatCurrency(totalRevenue)}</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">
                <span className="text-green-600">+12%</span> from last month
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-4 sm:p-6">
            <div className="space-y-2">
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Pending Payments</p>
              <p className="text-xl sm:text-2xl font-bold text-red-600">{formatCurrency(pendingAmount)}</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">
                <span className="text-red-600">-5%</span> from last month
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-4 sm:p-6">
            <div className="space-y-2">
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Paid Bills</p>
              <p className="text-xl sm:text-2xl font-bold text-blue-600">{paidBills}</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">
                <span className="text-green-600">+8%</span> from last month
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-4 sm:p-6">
            <div className="space-y-2">
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Pending Bills</p>
              <p className="text-xl sm:text-2xl font-bold text-orange-600">{pendingBills}</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">
                <span className="text-yellow-600">+2%</span> from last month
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4 sm:p-6">
          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by patient name or invoice ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 touch-target"
              />
            </div>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-[180px] touch-target">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="partially_paid">Partially Paid</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" className="flex items-center space-x-2 touch-target">
                <Download className="h-4 w-4" />
                <span>Export</span>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bills List */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg sm:text-xl">Recent Bills ({filteredBills.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredBills.length === 0 ? (
              <div className="text-center py-8">
                <CreditCard className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No bills found</p>
                <Button onClick={() => setShowForm(true)} className="mt-4">
                  Generate First Bill
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Desktop View - Hidden on mobile */}
                <div className="hidden lg:block space-y-4">
                  {filteredBills.map((bill) => (
                    <div
                      key={bill.id}
                      className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
                          <CreditCard className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                        </div>
                        
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <h3 className="font-semibold text-gray-900 dark:text-gray-100">{bill.id}</h3>
                            <Badge variant="outline">{bill.patientName}</Badge>
                          </div>
                          <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                            <p>Date: {new Date(bill.createdAt).toLocaleDateString()} | Due: {new Date(bill.dueDate).toLocaleDateString()}</p>
                            {bill.paymentMethod && (
                              <p>Payment Method: {bill.paymentMethod}</p>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="text-right space-y-2">
                        <div>
                          <p className="text-lg font-bold text-gray-900 dark:text-gray-100">
                            {formatCurrency(bill.total)}
                          </p>
                          {bill.paidAmount > 0 && bill.paidAmount < bill.total && (
                            <p className="text-sm text-green-600">
                              Paid: {formatCurrency(bill.paidAmount)}
                            </p>
                          )}
                          {bill.paidAmount < bill.total && (
                            <p className="text-sm text-red-600">
                              Due: {formatCurrency(bill.total - bill.paidAmount)}
                            </p>
                          )}
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          {getStatusIcon(bill.status)}
                          <Badge className={getStatusColor(bill.status)}>
                            {bill.status.replace('_', ' ')}
                          </Badge>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 ml-4">
                        <Button variant="ghost" size="sm" onClick={() => generateInvoicePDF(bill)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => generateInvoicePDF(bill)}>
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => setEditingBill(bill)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        {bill.status !== 'paid' && (
                          <Button 
                            variant="default" 
                            size="sm"
                            onClick={() => {
                              const amount = prompt(`Enter payment amount (Due: ${formatCurrency(bill.total - bill.paidAmount)}):`);
                              if (amount && !isNaN(parseFloat(amount))) {
                                handlePaymentUpdate(bill.id, parseFloat(amount));
                              }
                            }}
                          >
                            Collect Payment
                          </Button>
                        )}
                        <Button variant="ghost" size="sm" className="text-red-600" onClick={() => handleDeleteBill(bill.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Mobile Card View - Visible on mobile */}
                <div className="lg:hidden space-y-4">
                  {filteredBills.map((bill) => (
                    <Card key={bill.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          {/* Header with invoice and status */}
                          <div className="flex items-start justify-between">
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
                                <CreditCard className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                              </div>
                              <div>
                                <h3 className="font-semibold text-gray-900 dark:text-gray-100">{bill.id}</h3>
                                <p className="text-sm text-gray-500 dark:text-gray-400">{bill.patientName}</p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              {getStatusIcon(bill.status)}
                              <Badge className={getStatusColor(bill.status)}>
                                {bill.status.replace('_', ' ')}
                              </Badge>
                            </div>
                          </div>

                          {/* Amount details */}
                          <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-3">
                            <div className="space-y-2">
                              <div className="flex justify-between items-center">
                                <span className="text-sm text-gray-600 dark:text-gray-400">Total Amount:</span>
                                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">
                                  {formatCurrency(bill.total)}
                                </span>
                              </div>
                              {bill.paidAmount > 0 && (
                                <div className="flex justify-between items-center">
                                  <span className="text-sm text-gray-600 dark:text-gray-400">Paid:</span>
                                  <span className="text-sm font-medium text-green-600">
                                    {formatCurrency(bill.paidAmount)}
                                  </span>
                                </div>
                              )}
                              {bill.paidAmount < bill.total && (
                                <div className="flex justify-between items-center">
                                  <span className="text-sm text-gray-600 dark:text-gray-400">Due:</span>
                                  <span className="text-sm font-medium text-red-600">
                                    {formatCurrency(bill.total - bill.paidAmount)}
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Bill details */}
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-500 dark:text-gray-400">Date:</span>
                              <span className="text-gray-900 dark:text-gray-100">{new Date(bill.createdAt).toLocaleDateString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500 dark:text-gray-400">Due Date:</span>
                              <span className="text-gray-900 dark:text-gray-100">{new Date(bill.dueDate).toLocaleDateString()}</span>
                            </div>
                            {bill.paymentMethod && (
                              <div className="flex justify-between">
                                <span className="text-gray-500 dark:text-gray-400">Payment Method:</span>
                                <span className="text-gray-900 dark:text-gray-100">{bill.paymentMethod}</span>
                              </div>
                            )}
                          </div>

                          {/* Actions */}
                          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-gray-100 dark:border-gray-800">
                            <Button variant="ghost" size="sm" onClick={() => generateInvoicePDF(bill)} className="touch-target">
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => setEditingBill(bill)} className="touch-target">
                              <Edit className="h-4 w-4 mr-1" />
                              Edit
                            </Button>
                            {bill.status !== 'paid' && (
                              <Button 
                                variant="default" 
                                size="sm"
                                className="col-span-2 touch-target"
                                onClick={() => {
                                  const amount = prompt(`Enter payment amount (Due: ${formatCurrency(bill.total - bill.paidAmount)}):`);
                                  if (amount && !isNaN(parseFloat(amount))) {
                                    handlePaymentUpdate(bill.id, parseFloat(amount));
                                  }
                                }}
                              >
                                Collect Payment
                              </Button>
                            )}
                            <Button variant="ghost" size="sm" className="text-red-600 touch-target" onClick={() => handleDeleteBill(bill.id)}>
                              <Trash2 className="h-4 w-4 mr-1" />
                              Delete
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => generateInvoicePDF(bill)} className="touch-target">
                              <Download className="h-4 w-4 mr-1" />
                              Download
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Forms */}
      {showForm && (
        <BillForm
          onClose={() => setShowForm(false)}
          onSubmit={handleAddBill}
          patients={patients.map(p => ({ id: p.id, name: p.name, phone: p.phone }))}
        />
      )}

      {editingBill && (
        <BillForm
          onClose={() => setEditingBill(null)}
          onSubmit={handleEditBill}
          bill={editingBill}
          isEdit={true}
          patients={patients.map(p => ({ id: p.id, name: p.name, phone: p.phone }))}
        />
      )}
    </div>
  );
};

export default Billing;
