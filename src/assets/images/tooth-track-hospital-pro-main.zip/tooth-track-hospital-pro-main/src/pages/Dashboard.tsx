// Dashboard component for hospital management
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  Calendar, 
  DollarSign, 
  AlertTriangle, 
  Plus, 
  FileText,
  Package,
  Phone,
  TrendingUp,
  Clock,
  CreditCard
} from 'lucide-react';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { Patient, Appointment, Bill } from '@/types';

const Dashboard = () => {
  const navigate = useNavigate();
  const [patients] = useLocalStorage<Patient[]>('patients', []);
  const [appointments] = useLocalStorage<Appointment[]>('appointments', []);
  const [bills] = useLocalStorage<Bill[]>('bills', []);

  // Calculate dashboard metrics
  const totalPatients = patients.length;
  const activePatients = patients.filter(p => {
    const lastVisit = new Date(p.updatedAt);
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    return lastVisit > sixMonthsAgo;
  }).length;

  const today = new Date();
  const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const todayEnd = new Date(todayStart.getTime() + 24 * 60 * 60 * 1000);

  const todaysAppointments = appointments.filter(apt => {
    const aptDate = new Date(apt.date);
    return aptDate >= todayStart && aptDate < todayEnd;
  }).length;

  const confirmedAppointments = appointments.filter(apt => apt.status === 'confirmed').length;

  const monthlyRevenue = bills.reduce((total, bill) => total + bill.total, 0);
  const pendingPayments = bills.filter(bill => bill.status === 'pending').reduce((total, bill) => total + bill.total, 0);

  const newThisMonth = patients.filter(patient => {
    const createdDate = new Date(patient.createdAt);
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    return createdDate >= startOfMonth;
  }).length;

  // Recent activities
  const recentAppointments = appointments
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const recentPatients = patients
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const pendingBills = bills.filter(bill => bill.status === 'pending').slice(0, 5);

  const quickActions = [
    {
      title: 'Add New Patient',
      description: 'Register a new patient',
      icon: Users,
      action: () => navigate('/patients'),
      color: 'bg-blue-500 hover:bg-blue-600'
    },
    {
      title: 'Schedule Appointment',
      description: 'Book new appointment',
      icon: Calendar,
      action: () => navigate('/appointments'),
      color: 'bg-green-500 hover:bg-green-600'
    },
    {
      title: 'Generate Bill',
      description: 'Create new invoice',
      icon: CreditCard,
      action: () => navigate('/billing'),
      color: 'bg-purple-500 hover:bg-purple-600'
    },
    {
      title: 'View Reports',
      description: 'Check analytics',
      icon: FileText,
      action: () => navigate('/reports'),
      color: 'bg-orange-500 hover:bg-orange-600'
    }
  ];

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 text-sm lg:text-base">Hospital Management Overview</p>
        </div>
        <div className="text-right">
          <p className="text-lg lg:text-xl font-semibold text-gray-900">
            {new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </p>
          <p className="text-sm text-gray-600">
            {new Date().toLocaleTimeString('en-US', { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4 lg:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-blue-600">{totalPatients}</p>
                <p className="text-xs lg:text-sm text-gray-600">Total Patients</p>
                <div className="flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 lg:h-4 lg:w-4 text-green-500 mr-1" />
                  <span className="text-xs text-green-600">+{newThisMonth} this month</span>
                </div>
              </div>
              <Users className="h-8 w-8 lg:h-10 lg:w-10 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4 lg:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-green-600">{todaysAppointments}</p>
                <p className="text-xs lg:text-sm text-gray-600">Today's Appointments</p>
                <div className="flex items-center mt-1">
                  <Clock className="h-3 w-3 lg:h-4 lg:w-4 text-blue-500 mr-1" />
                  <span className="text-xs text-blue-600">{confirmedAppointments} confirmed</span>
                </div>
              </div>
              <Calendar className="h-8 w-8 lg:h-10 lg:w-10 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4 lg:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-purple-600">₹{monthlyRevenue.toLocaleString()}</p>
                <p className="text-xs lg:text-sm text-gray-600">Monthly Revenue</p>
                <div className="flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 lg:h-4 lg:w-4 text-green-500 mr-1" />
                  <span className="text-xs text-green-600">+12% vs last month</span>
                </div>
              </div>
              <DollarSign className="h-8 w-8 lg:h-10 lg:w-10 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4 lg:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-red-600">₹{pendingPayments.toLocaleString()}</p>
                <p className="text-xs lg:text-sm text-gray-600">Pending Payments</p>
                <div className="flex items-center mt-1">
                  <AlertTriangle className="h-3 w-3 lg:h-4 lg:w-4 text-red-500 mr-1" />
                  <span className="text-xs text-red-600">{pendingBills.length} bills</span>
                </div>
              </div>
              <CreditCard className="h-8 w-8 lg:h-10 lg:w-10 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg lg:text-xl">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
            {quickActions.map((action, index) => (
              <Button
                key={index}
                onClick={action.action}
                className={`${action.color} text-white h-auto p-4 flex flex-col items-center space-y-2 hover:scale-105 transition-transform`}
              >
                <action.icon className="h-6 w-6 lg:h-8 lg:w-8" />
                <div className="text-center">
                  <p className="font-semibold text-sm lg:text-base">{action.title}</p>
                  <p className="text-xs opacity-90">{action.description}</p>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4 lg:gap-6">
        {/* Recent Appointments */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base lg:text-lg flex items-center">
              <Calendar className="h-4 w-4 lg:h-5 lg:w-5 mr-2" />
              Recent Appointments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentAppointments.length === 0 ? (
                <p className="text-sm text-gray-500 text-center py-4">No appointments yet</p>
              ) : (
                recentAppointments.map((appointment) => (
                  <div key={appointment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm lg:text-base truncate">{appointment.patientName}</p>
                      <p className="text-xs lg:text-sm text-gray-600">
                        {new Date(appointment.date).toLocaleDateString()} at {appointment.time}
                      </p>
                      <p className="text-xs text-gray-500">{appointment.type}</p>
                    </div>
                    <Badge 
                      variant={appointment.status === 'confirmed' ? 'default' : 'secondary'}
                      className="text-xs"
                    >
                      {appointment.status}
                    </Badge>
                  </div>
                ))
              )}
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full mt-3" 
              onClick={() => navigate('/appointments')}
            >
              View All Appointments
            </Button>
          </CardContent>
        </Card>

        {/* Recent Patients */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base lg:text-lg flex items-center">
              <Users className="h-4 w-4 lg:h-5 lg:w-5 mr-2" />
              Recent Patients
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentPatients.length === 0 ? (
                <p className="text-sm text-gray-500 text-center py-4">No patients yet</p>
              ) : (
                recentPatients.map((patient) => (
                  <div key={patient.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div className="w-8 h-8 lg:w-10 lg:h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-600 font-semibold text-sm lg:text-base">
                        {patient.name.charAt(0)}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm lg:text-base truncate">{patient.name}</p>
                      <p className="text-xs lg:text-sm text-gray-600 truncate">{patient.phone}</p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      New
                    </Badge>
                  </div>
                ))
              )}
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full mt-3" 
              onClick={() => navigate('/patients')}
            >
              View All Patients
            </Button>
          </CardContent>
        </Card>

        {/* Pending Payments */}
        <Card className="lg:col-span-2 xl:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="text-base lg:text-lg flex items-center">
              <AlertTriangle className="h-4 w-4 lg:h-5 lg:w-5 mr-2 text-red-500" />
              Pending Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingBills.length === 0 ? (
                <p className="text-sm text-gray-500 text-center py-4">All payments up to date!</p>
              ) : (
                pendingBills.map((bill) => (
                  <div key={bill.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm lg:text-base truncate">{bill.patientName}</p>
                      <p className="text-xs lg:text-sm text-gray-600">
                        Bill #{bill.id.slice(-6).toUpperCase()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-red-600 text-sm lg:text-base">₹{bill.total}</p>
                      <Badge variant="destructive" className="text-xs">
                        {bill.status}
                      </Badge>
                    </div>
                  </div>
                ))
              )}
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full mt-3" 
              onClick={() => navigate('/billing')}
            >
              View All Bills
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* System Alerts */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base lg:text-lg flex items-center">
            <AlertTriangle className="h-4 w-4 lg:h-5 lg:w-5 mr-2 text-orange-500" />
            System Alerts & Notifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
              <Users className="h-5 w-5 text-blue-500 flex-shrink-0" />
              <div>
                <p className="font-medium text-sm">New Patients</p>
                <p className="text-xs text-gray-600">{newThisMonth} added this month</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
              <Calendar className="h-5 w-5 text-green-500 flex-shrink-0" />
              <div>
                <p className="font-medium text-sm">Appointments</p>
                <p className="text-xs text-gray-600">{todaysAppointments} scheduled today</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 p-3 bg-red-50 rounded-lg">
              <CreditCard className="h-5 w-5 text-red-500 flex-shrink-0" />
              <div>
                <p className="font-medium text-sm">Pending Payments</p>
                <p className="text-xs text-gray-600">₹{pendingPayments.toLocaleString()} overdue</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
              <Package className="h-5 w-5 text-purple-500 flex-shrink-0" />
              <div>
                <p className="font-medium text-sm">Inventory</p>
                <p className="text-xs text-gray-600">Stock levels normal</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;