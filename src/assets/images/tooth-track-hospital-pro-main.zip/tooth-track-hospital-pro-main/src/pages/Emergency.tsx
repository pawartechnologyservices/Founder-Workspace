
import React from 'react';
import { Phone, MapPin, Clock, AlertTriangle, User, Hospital } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const Emergency = () => {
  const emergencyContacts = [
    {
      id: '1',
      name: 'Dr. Sarah Johnson',
      role: 'Emergency Dentist',
      phone: '+1234567890',
      email: 'sarah.johnson@hospital.com',
      isOnCall: true,
      specialty: 'Oral Surgery',
      location: 'Main Hospital'
    },
    {
      id: '2',
      name: 'Dr. Mike Davis',
      role: 'On-Call Dentist',
      phone: '+1234567891',
      email: 'mike.davis@hospital.com',
      isOnCall: true,
      specialty: 'General Dentistry',
      location: 'Emergency Wing'
    },
    {
      id: '3',
      name: 'Dr. Emily Rodriguez',
      role: 'Pediatric Dentist',
      phone: '+1234567892',
      email: 'emily.rodriguez@hospital.com',
      isOnCall: false,
      specialty: 'Pediatric Dentistry',
      location: 'Children\'s Wing'
    },
    {
      id: '4',
      name: 'Dr. James Wilson',
      role: 'Orthodontist',
      phone: '+1234567893',
      email: 'james.wilson@hospital.com',
      isOnCall: true,
      specialty: 'Orthodontics',
      location: 'Orthodontic Department'
    },
  ];

  const emergencyProcedures = [
    {
      id: '1',
      title: 'Severe Tooth Pain',
      steps: [
        'Administer pain relief medication',
        'Examine the affected area',
        'Take X-rays if necessary',
        'Provide temporary filling or treatment',
        'Schedule follow-up appointment'
      ],
      priority: 'high'
    },
    {
      id: '2',
      title: 'Dental Trauma/Injury',
      steps: [
        'Control bleeding immediately',
        'Assess airway and breathing',
        'Preserve any knocked-out teeth',
        'Apply cold compress for swelling',
        'Contact emergency services if severe'
      ],
      priority: 'critical'
    },
    {
      id: '3',
      title: 'Swelling/Infection',
      steps: [
        'Assess severity of swelling',
        'Check vital signs',
        'Prescribe antibiotics if needed',
        'Drain abscess if present',
        'Monitor for complications'
      ],
      priority: 'high'
    },
  ];

  const hospitalInfo = {
    name: 'Dr sneha Dental Clinic',
    address: '123 Medical Center Blvd, Healthcare City, HC 12345',
    phone: '+1-800-DENTAL-911',
    emergencyLine: '+1-800-911-DENT',
    hours: '24/7 Emergency Services Available'
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="bg-red-600 text-white rounded-lg p-6">
        <div className="flex items-center space-x-3">
          <AlertTriangle className="h-8 w-8" />
          <div>
            <h1 className="text-2xl font-bold">Emergency Center</h1>
            <p className="text-red-100">Quick access to emergency contacts and procedures</p>
          </div>
        </div>
      </div>

      {/* Quick Emergency Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <Phone className="h-8 w-8 text-red-600 mx-auto mb-3" />
            <h3 className="font-bold text-lg text-red-800 mb-2">Emergency Hotline</h3>
            <p className="text-2xl font-bold text-red-600 mb-3">
              {hospitalInfo.emergencyLine}
            </p>
            <Button className="bg-red-600 hover:bg-red-700 w-full">
              Call Now
            </Button>
          </CardContent>
        </Card>

        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="p-6 text-center">
            <Hospital className="h-8 w-8 text-orange-600 mx-auto mb-3" />
            <h3 className="font-bold text-lg text-orange-800 mb-2">Hospital Location</h3>
            <p className="text-sm text-orange-700 mb-3">{hospitalInfo.address}</p>
            <Button variant="outline" className="border-orange-600 text-orange-600 w-full">
              Get Directions
            </Button>
          </CardContent>
        </Card>

        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-6 text-center">
            <Clock className="h-8 w-8 text-blue-600 mx-auto mb-3" />
            <h3 className="font-bold text-lg text-blue-800 mb-2">Emergency Hours</h3>
            <p className="text-blue-700 mb-3">{hospitalInfo.hours}</p>
            <Badge className="bg-green-100 text-green-800">
              Currently Open
            </Badge>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Emergency Contacts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <User className="h-5 w-5" />
              <span>Emergency Contacts</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {emergencyContacts.map((contact) => (
                <div
                  key={contact.id}
                  className={`p-4 rounded-lg border-2 ${
                    contact.isOnCall 
                      ? 'border-green-200 bg-green-50' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <User className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{contact.name}</h3>
                        <p className="text-sm text-gray-600">{contact.role}</p>
                      </div>
                    </div>
                    <Badge 
                      className={contact.isOnCall ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}
                    >
                      {contact.isOnCall ? 'On Call' : 'Off Duty'}
                    </Badge>
                  </div>
                  
                  <div className="text-sm text-gray-600 space-y-1 mb-3">
                    <div className="flex items-center space-x-2">
                      <Phone className="h-3 w-3" />
                      <span>{contact.phone}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-3 w-3" />
                      <span>{contact.location}</span>
                    </div>
                    <p>Specialty: {contact.specialty}</p>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button size="sm" className="flex-1">
                      <Phone className="h-3 w-3 mr-1" />
                      Call
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      Message
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Emergency Procedures */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5" />
              <span>Emergency Procedures</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {emergencyProcedures.map((procedure) => (
                <div
                  key={procedure.id}
                  className="p-4 border rounded-lg"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-gray-900">{procedure.title}</h3>
                    <Badge 
                      className={
                        procedure.priority === 'critical' 
                          ? 'bg-red-100 text-red-800'
                          : procedure.priority === 'high'
                          ? 'bg-orange-100 text-orange-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }
                    >
                      {procedure.priority}
                    </Badge>
                  </div>
                  
                  <ol className="text-sm text-gray-600 space-y-1">
                    {procedure.steps.map((step, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <span className="text-blue-600 font-medium">{index + 1}.</span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Hospital Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Hospital className="h-5 w-5" />
            <span>Hospital Information</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">Contact Information</h3>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-center space-x-2">
                  <Hospital className="h-4 w-4" />
                  <span>{hospitalInfo.name}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4" />
                  <span>{hospitalInfo.address}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span>Main: {hospitalInfo.phone}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span>Emergency: {hospitalInfo.emergencyLine}</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">Important Notes</h3>
              <div className="text-sm text-gray-600 space-y-2">
                <p>• Emergency services available 24/7</p>
                <p>• Ambulance service can be arranged</p>
                <p>• All major insurance plans accepted</p>
                <p>• Emergency room located on ground floor</p>
                <p>• Parking available in emergency zone</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Emergency;
