import React, { useState } from 'react';
import { Package, Search, Plus, AlertTriangle, TrendingDown, TrendingUp, BarChart3, Edit, FileDown, FileUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import InventoryForm from '@/components/forms/InventoryForm';
import { InventoryItem } from '@/types';

const Inventory = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const { toast } = useToast();

  // Initial inventory data
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([
    {
      id: '1',
      name: 'Dental Floss',
      category: 'supplies',
      currentStock: 5,
      minStock: 20,
      maxStock: 100,
      unit: 'pcs',
      costPerUnit: 25,
      supplier: 'MedSupply Co.',
      expiryDate: new Date('2024-12-31'),
      lastRestocked: new Date('2024-01-10'),
      status: 'low_stock'
    },
    {
      id: '2',
      name: 'Dental Drill Bits',
      category: 'instruments',
      currentStock: 45,
      minStock: 20,
      maxStock: 50,
      unit: 'set',
      costPerUnit: 150,
      supplier: 'DentalTools Ltd.',
      expiryDate: undefined,
      lastRestocked: new Date('2024-01-05'),
      status: 'in_stock'
    },
    {
      id: '3',
      name: 'Anesthetic (Lidocaine)',
      category: 'medicines',
      currentStock: 15,
      minStock: 10,
      maxStock: 30,
      unit: 'vials',
      costPerUnit: 45,
      supplier: 'PharmaCorp',
      expiryDate: new Date('2024-06-30'),
      lastRestocked: new Date('2024-01-15'),
      status: 'in_stock'
    },
    {
      id: '4',
      name: 'Disposable Gloves',
      category: 'supplies',
      currentStock: 0,
      minStock: 50,
      maxStock: 200,
      unit: 'boxes',
      costPerUnit: 12,
      supplier: 'SafetyFirst Inc.',
      expiryDate: new Date('2025-01-31'),
      lastRestocked: new Date('2023-12-20'),
      status: 'out_of_stock'
    },
    {
      id: '5',
      name: 'X-Ray Machine',
      category: 'equipment',
      currentStock: 1,
      minStock: 1,
      maxStock: 2,
      unit: 'unit',
      costPerUnit: 150000,
      supplier: 'MedEquip Solutions',
      expiryDate: undefined,
      lastRestocked: new Date('2023-06-15'),
      status: 'in_stock'
    },
  ]);

  const filteredItems = inventoryItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.supplier.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const handleAddItem = (data: any) => {
    const newItem: InventoryItem = {
      id: Date.now().toString(),
      ...data,
      lastRestocked: new Date(),
      status: data.currentStock === 0 ? 'out_of_stock' : 
              data.currentStock <= data.minStock ? 'low_stock' : 'in_stock'
    };
    
    setInventoryItems(prev => [...prev, newItem]);
    setShowForm(false);
    toast({
      title: 'Success',
      description: 'Inventory item added successfully',
    });
  };

  const handleEditItem = (data: any) => {
    if (!editingItem) return;
    
    const updatedItem: InventoryItem = {
      ...editingItem,
      ...data,
      status: data.currentStock === 0 ? 'out_of_stock' : 
              data.currentStock <= data.minStock ? 'low_stock' : 'in_stock'
    };
    
    setInventoryItems(prev => 
      prev.map(item => item.id === editingItem.id ? updatedItem : item)
    );
    setEditingItem(null);
    toast({
      title: 'Success',
      description: 'Inventory item updated successfully',
    });
  };

  const handleRestock = (itemId: string, quantity: number) => {
    setInventoryItems(prev => 
      prev.map(item => {
        if (item.id === itemId) {
          const newStock = item.currentStock + quantity;
          return {
            ...item,
            currentStock: newStock,
            lastRestocked: new Date(),
            status: newStock === 0 ? 'out_of_stock' : 
                    newStock <= item.minStock ? 'low_stock' : 'in_stock'
          };
        }
        return item;
      })
    );
    
    toast({
      title: 'Success',
      description: 'Item restocked successfully',
    });
  };

  const handleExportData = () => {
    const dataStr = JSON.stringify(inventoryItems, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = 'inventory-data.json';
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    toast({
      title: 'Success',
      description: 'Inventory data exported successfully',
    });
  };

  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedData = JSON.parse(e.target?.result as string);
        setInventoryItems(importedData);
        toast({
          title: 'Success',
          description: 'Inventory data imported successfully',
        });
      } catch (error) {
        toast({
          title: 'Error',
          description: 'Failed to import data. Please check the file format.',
          variant: 'destructive',
        });
      }
    };
    reader.readAsText(file);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in_stock':
        return 'bg-green-100 text-green-800';
      case 'low_stock':
        return 'bg-yellow-100 text-yellow-800';
      case 'out_of_stock':
        return 'bg-red-100 text-red-800';
      case 'expired':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'in_stock':
        return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'low_stock':
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case 'out_of_stock':
        return <TrendingDown className="h-4 w-4 text-red-600" />;
      case 'expired':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default:
        return <BarChart3 className="h-4 w-4 text-gray-600" />;
    }
  };

  const getStockPercentage = (current: number, max: number) => {
    return Math.round((current / max) * 100);
  };

  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString()}`;
  };

  const lowStockItems = inventoryItems.filter(item => item.status === 'low_stock' || item.status === 'out_of_stock');
  const totalValue = inventoryItems.reduce((sum, item) => sum + (item.currentStock * item.costPerUnit), 0);

  return (
    <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">Inventory Management</h1>
          <p className="text-sm text-gray-600 dark:text-gray-400">Track and manage medical supplies and equipment</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleExportData}
              className="flex items-center space-x-2"
            >
              <FileDown className="h-4 w-4" />
              <span>Export</span>
            </Button>
            <label htmlFor="import-file">
              <Button
                variant="outline"
                size="sm"
                className="flex items-center space-x-2"
                asChild
              >
                <span>
                  <FileUp className="h-4 w-4" />
                  <span>Import</span>
                </span>
              </Button>
              <input
                id="import-file"
                type="file"
                accept=".json"
                onChange={handleImportData}
                className="hidden"
              />
            </label>
          </div>
          <Button 
            className="flex items-center space-x-2"
            onClick={() => setShowForm(true)}
          >
            <Plus className="h-4 w-4" />
            <span>Add New Item</span>
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
        {[
          { 
            label: 'Total Items', 
            value: inventoryItems.length.toString(), 
            color: 'text-blue-600',
            icon: Package
          },
          { 
            label: 'Low Stock Alerts', 
            value: lowStockItems.length.toString(), 
            color: 'text-red-600',
            icon: AlertTriangle
          },
          { 
            label: 'Total Value', 
            value: formatCurrency(totalValue), 
            color: 'text-green-600',
            icon: TrendingUp
          },
          { 
            label: 'Categories', 
            value: '4', 
            color: 'text-purple-600',
            icon: BarChart3
          },
        ].map((stat, index) => (
          <Card key={index}>
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">{stat.label}</p>
                  <p className={`text-lg sm:text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                </div>
                <div className={`p-2 sm:p-3 rounded-full bg-gray-50 dark:bg-gray-800`}>
                  <stat.icon className={`h-4 w-4 sm:h-6 sm:w-6 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Low Stock Alerts */}
      {lowStockItems.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-red-600">
              <AlertTriangle className="h-5 w-5" />
              <span>Low Stock Alerts</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {lowStockItems.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
                  <div>
                    <p className="font-semibold text-red-800 dark:text-red-200">{item.name}</p>
                    <p className="text-sm text-red-600 dark:text-red-400">
                      Current: {item.currentStock} {item.unit} | Min: {item.minStock} {item.unit}
                    </p>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-red-600 border-red-300 dark:border-red-700"
                    onClick={() => handleRestock(item.id, item.minStock)}
                  >
                    Restock Now
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4 sm:p-6">
          <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by item name or supplier..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Filter by category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="instruments">Instruments</SelectItem>
                <SelectItem value="medicines">Medicines</SelectItem>
                <SelectItem value="supplies">Supplies</SelectItem>
                <SelectItem value="equipment">Equipment</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Inventory List */}
      <Card>
        <CardHeader>
          <CardTitle>Inventory Items</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="flex flex-col lg:flex-row lg:items-center justify-between p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 space-y-4 lg:space-y-0"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0">
                    <Package className="h-6 w-6 text-blue-600" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <h3 className="font-semibold text-gray-900 dark:text-white truncate">{item.name}</h3>
                      <Badge variant="outline" className="capitalize">
                        {item.category}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                      <p>Supplier: {item.supplier}</p>
                      <p>Cost per unit: {formatCurrency(item.costPerUnit)}</p>
                      <p>Last restocked: {item.lastRestocked.toLocaleDateString()}</p>
                      {item.expiryDate && (
                        <p>Expires: {item.expiryDate.toLocaleDateString()}</p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col lg:flex-row lg:items-center space-y-4 lg:space-y-0 lg:space-x-6">
                  <div className="text-left lg:text-right space-y-2 min-w-[200px]">
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(item.status)}
                      <Badge className={getStatusColor(item.status)}>
                        {item.status.replace('_', ' ')}
                      </Badge>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>Stock:</span>
                        <span className="font-medium">
                          {item.currentStock}/{item.maxStock} {item.unit}
                        </span>
                      </div>
                      <Progress 
                        value={getStockPercentage(item.currentStock, item.maxStock)} 
                        className="h-2"
                      />
                    </div>
                    
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      Value: {formatCurrency(item.currentStock * item.costPerUnit)}
                    </p>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setEditingItem(item)}
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    <Button 
                      variant="default" 
                      size="sm"
                      onClick={() => handleRestock(item.id, 10)}
                    >
                      Restock
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Item Dialog */}
      <Dialog open={showForm || !!editingItem} onOpenChange={(open) => {
        if (!open) {
          setShowForm(false);
          setEditingItem(null);
        }
      }}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <InventoryForm
            onSubmit={editingItem ? handleEditItem : handleAddItem}
            onCancel={() => {
              setShowForm(false);
              setEditingItem(null);
            }}
            initialData={editingItem || undefined}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Inventory;
