
import React, { useState } from 'react';
import { Users, Search, Plus, Edit, Trash2, Phone, Mail, Calendar, MapPin, User, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import PatientForm from '@/components/forms/PatientForm';
import { Patient } from '@/types';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { useToast } from '@/hooks/use-toast';

const Patients = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [patients, setPatients] = useLocalStorage<Patient[]>('patients', []);
  const { toast } = useToast();

  // Helper function to calculate age from date of birth
  const calculateAge = (dateOfBirth: Date) => {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  // Helper function to get patient status (default to 'active' if not set)
  const getPatientStatus = (patient: Patient) => {
    return patient.status || 'active';
  };

  // Helper function to get last visit date (mock for now)
  const getLastVisitDate = (patient: Patient) => {
    return patient.lastVisit || null;
  };

  const filteredPatients = patients.filter(patient => {
    const matchesSearch = patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         patient.phone.includes(searchTerm) ||
                         patient.email.toLowerCase().includes(searchTerm.toLowerCase());
    const patientStatus = getPatientStatus(patient);
    const matchesStatus = statusFilter === 'all' || patientStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'inactive':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
      case 'new':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const handleAddPatient = (patientData: Omit<Patient, 'id' | 'createdAt'>) => {
    const newPatient: Patient = {
      ...patientData,
      id: `PAT-${Date.now()}`,
      createdAt: new Date(),
      status: patientData.status || 'new' // Default to 'new' if not provided
    };
    
    setPatients(prev => [...prev, newPatient]);
    setShowForm(false);
    toast({
      title: "Success",
      description: "Patient added successfully",
    });
  };

  const handleEditPatient = (patientData: Omit<Patient, 'id' | 'createdAt'>) => {
    if (!editingPatient) return;
    
    const updatedPatient: Patient = {
      ...patientData,
      id: editingPatient.id,
      createdAt: editingPatient.createdAt
    };
    
    setPatients(prev => prev.map(p => p.id === editingPatient.id ? updatedPatient : p));
    setEditingPatient(null);
    toast({
      title: "Success",
      description: "Patient updated successfully",
    });
  };

  const handleDeletePatient = (patientId: string) => {
    if (confirm('Are you sure you want to delete this patient?')) {
      setPatients(prev => prev.filter(p => p.id !== patientId));
      toast({
        title: "Success",
        description: "Patient deleted successfully",
      });
    }
  };

  const activePatients = patients.filter(p => getPatientStatus(p) === 'active').length;
  const newPatients = patients.filter(p => getPatientStatus(p) === 'new').length;
  const totalAppointments = patients.reduce((sum, p) => sum + (p.appointments?.length || 0), 0);

  return (
    <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-gray-100">Patient Management</h1>
          <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">Manage patient information and records</p>
        </div>
        <Button 
          className="flex items-center justify-center space-x-2 w-full sm:w-auto touch-target" 
          onClick={() => setShowForm(true)}
        >
          <Plus className="h-4 w-4" />
          <span>Add New Patient</span>
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-4 sm:p-6">
            <div className="space-y-2">
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Total Patients</p>
              <p className="text-xl sm:text-2xl font-bold text-blue-600">{patients.length}</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">
                <span className="text-green-600">+12%</span> from last month
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-4 sm:p-6">
            <div className="space-y-2">
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Active Patients</p>
              <p className="text-xl sm:text-2xl font-bold text-green-600">{activePatients}</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">
                <span className="text-green-600">+8%</span> from last month
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-4 sm:p-6">
            <div className="space-y-2">
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">New Patients</p>
              <p className="text-xl sm:text-2xl font-bold text-orange-600">{newPatients}</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">
                <span className="text-yellow-600">+5%</span> from last month
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-4 sm:p-6">
            <div className="space-y-2">
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Total Appointments</p>
              <p className="text-xl sm:text-2xl font-bold text-purple-600">{totalAppointments}</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">
                <span className="text-green-600">+15%</span> from last month
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4 sm:p-6">
          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by name, phone, or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 touch-target"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[180px] touch-target">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="new">New</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Patients List */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg sm:text-xl">Patients ({filteredPatients.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredPatients.length === 0 ? (
            <div className="text-center py-8">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No patients found</p>
              <Button onClick={() => setShowForm(true)} className="mt-4">
                Add First Patient
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Desktop Table View - Hidden on mobile */}
              <div className="hidden lg:block overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-700">
                      <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-gray-100">Patient</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-gray-100">Contact</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-gray-100">Age</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-gray-100">Status</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-gray-100">Last Visit</th>
                      <th className="text-right py-3 px-4 font-medium text-gray-900 dark:text-gray-100">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredPatients.map((patient) => {
                      const age = patient.age || calculateAge(patient.dateOfBirth);
                      const status = getPatientStatus(patient);
                      const lastVisit = getLastVisitDate(patient);
                      
                      return (
                        <tr key={patient.id} className="border-b border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50">
                          <td className="py-3 px-4">
                            <div className="flex items-center space-x-3">
                              <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
                                <User className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                              </div>
                              <div>
                                <p className="font-medium text-gray-900 dark:text-gray-100">{patient.name}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">{patient.id}</p>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="space-y-1">
                              <div className="flex items-center space-x-2">
                                <Phone className="h-3 w-3 text-gray-400" />
                                <span className="text-sm text-gray-600 dark:text-gray-400">{patient.phone}</span>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Mail className="h-3 w-3 text-gray-400" />
                                <span className="text-sm text-gray-600 dark:text-gray-400">{patient.email}</span>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <span className="text-sm text-gray-900 dark:text-gray-100">{age}</span>
                          </td>
                          <td className="py-3 px-4">
                            <Badge className={getStatusColor(status)}>
                              {status}
                            </Badge>
                          </td>
                          <td className="py-3 px-4">
                            <span className="text-sm text-gray-600 dark:text-gray-400">
                              {lastVisit ? new Date(lastVisit).toLocaleDateString() : 'Never'}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex items-center justify-end space-x-2">
                              <Button variant="ghost" size="sm" onClick={() => setSelectedPatient(patient)}>
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm" onClick={() => setEditingPatient(patient)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-red-600" onClick={() => handleDeletePatient(patient.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Mobile Card View - Visible on mobile */}
              <div className="lg:hidden space-y-4">
                {filteredPatients.map((patient) => {
                  const age = patient.age || calculateAge(patient.dateOfBirth);
                  const status = getPatientStatus(patient);
                  const lastVisit = getLastVisitDate(patient);
                  
                  return (
                    <Card key={patient.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          {/* Header with name and status */}
                          <div className="flex items-start justify-between">
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
                                <User className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                              </div>
                              <div>
                                <h3 className="font-medium text-gray-900 dark:text-gray-100">{patient.name}</h3>
                                <p className="text-sm text-gray-500 dark:text-gray-400">{patient.id}</p>
                              </div>
                            </div>
                            <Badge className={getStatusColor(status)}>
                              {status}
                            </Badge>
                          </div>

                          {/* Contact info */}
                          <div className="space-y-2">
                            <div className="flex items-center space-x-2">
                              <Phone className="h-4 w-4 text-gray-400" />
                              <span className="text-sm text-gray-600 dark:text-gray-400">{patient.phone}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Mail className="h-4 w-4 text-gray-400" />
                              <span className="text-sm text-gray-600 dark:text-gray-400 truncate">{patient.email}</span>
                            </div>
                            {patient.address && (
                              <div className="flex items-center space-x-2">
                                <MapPin className="h-4 w-4 text-gray-400" />
                                <span className="text-sm text-gray-600 dark:text-gray-400 truncate">{patient.address}</span>
                              </div>
                            )}
                          </div>

                          {/* Details */}
                          <div className="flex justify-between text-sm">
                            <div>
                              <span className="text-gray-500 dark:text-gray-400">Age: </span>
                              <span className="text-gray-900 dark:text-gray-100">{age}</span>
                            </div>
                            <div>
                              <span className="text-gray-500 dark:text-gray-400">Last Visit: </span>
                              <span className="text-gray-900 dark:text-gray-100">
                                {lastVisit ? new Date(lastVisit).toLocaleDateString() : 'Never'}
                              </span>
                            </div>
                          </div>

                          {/* Actions */}
                          <div className="flex items-center justify-end space-x-2 pt-2 border-t border-gray-100 dark:border-gray-800">
                            <Button variant="ghost" size="sm" onClick={() => setSelectedPatient(patient)} className="touch-target">
                              <Eye className="h-4 w-4" />
                              <span className="ml-1">View</span>
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => setEditingPatient(patient)} className="touch-target">
                              <Edit className="h-4 w-4" />
                              <span className="ml-1">Edit</span>
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-red-600 touch-target" 
                              onClick={() => handleDeletePatient(patient.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                              <span className="ml-1">Delete</span>
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Forms */}
      {showForm && (
        <PatientForm
          onClose={() => setShowForm(false)}
          onSubmit={handleAddPatient}
        />
      )}

      {editingPatient && (
        <PatientForm
          onClose={() => setEditingPatient(null)}
          onSubmit={handleEditPatient}
          patient={editingPatient}
          isEdit={true}
        />
      )}
    </div>
  );
};

export default Patients;
