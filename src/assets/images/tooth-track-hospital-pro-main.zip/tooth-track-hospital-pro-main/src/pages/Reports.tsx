import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart3, 
  Users, 
  Calendar, 
  DollarSign, 
  Download, 
  TrendingUp,
  FileText,
  Eye
} from 'lucide-react';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { Patient, Appointment, Bill } from '@/types';

const Reports = () => {
  const [patients] = useLocalStorage<Patient[]>('patients', []);
  const [appointments] = useLocalStorage<Appointment[]>('appointments', []);
  const [bills] = useLocalStorage<Bill[]>('bills', []);
  const [period, setPeriod] = useState('monthly');
  const { toast } = useToast();
  const navigate = useNavigate();

  // Calculate metrics based on selected period
  const calculateMetrics = () => {
    const now = new Date();
    let startDate: Date;

    switch (period) {
      case 'daily':
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'weekly':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'monthly':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'yearly':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    }

    // Patient metrics
    const totalPatients = patients.length;
    const newPatients = patients.filter(p => new Date(p.createdAt) >= startDate).length;
    const activePatients = patients.filter(p => {
      const lastVisit = new Date(p.updatedAt);
      const sixMonthsAgo = new Date();
      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
      return lastVisit > sixMonthsAgo;
    }).length;

    // Appointment metrics
    const periodAppointments = appointments.filter(apt => new Date(apt.date) >= startDate);
    const totalAppointments = periodAppointments.length;
    const confirmedAppointments = periodAppointments.filter(apt => apt.status === 'confirmed').length;
    const completedAppointments = periodAppointments.filter(apt => apt.status === 'completed').length;
    const cancelledAppointments = periodAppointments.filter(apt => apt.status === 'cancelled').length;

    // Revenue metrics
    const periodBills = bills.filter(bill => new Date(bill.createdAt) >= startDate);
    const totalRevenue = periodBills.reduce((sum, bill) => sum + bill.total, 0);
    const paidRevenue = periodBills.filter(bill => bill.status === 'paid').reduce((sum, bill) => sum + bill.total, 0);
    const pendingRevenue = periodBills.filter(bill => bill.status === 'pending').reduce((sum, bill) => sum + bill.total, 0);

    // Treatment analysis
    const treatmentCounts = periodAppointments.reduce((acc, apt) => {
      const treatment = apt.type || 'consultation';
      acc[treatment] = (acc[treatment] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      patients: { total: totalPatients, new: newPatients, active: activePatients },
      appointments: { total: totalAppointments, confirmed: confirmedAppointments, completed: completedAppointments, cancelled: cancelledAppointments },
      revenue: { total: totalRevenue, paid: paidRevenue, pending: pendingRevenue },
      treatments: treatmentCounts
    };
  };

  const metrics = calculateMetrics();

  const handleExportReport = (type: 'pdf' | 'excel') => {
    toast({
      title: "Export Started",
      description: `Generating ${type.toUpperCase()} report for ${period} period...`,
    });
    
    // Simulate export process
    setTimeout(() => {
      toast({
        title: "Export Complete",
        description: `${type.toUpperCase()} report has been downloaded successfully.`,
      });
    }, 2000);
  };

  const getPeriodLabel = () => {
    switch (period) {
      case 'daily': return 'Today';
      case 'weekly': return 'This Week';
      case 'monthly': return 'This Month';
      case 'yearly': return 'This Year';
      default: return 'This Month';
    }
  };

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Reports & Analytics</h1>
          <p className="text-gray-600 text-sm lg:text-base">Hospital performance insights and data analysis</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="yearly">Yearly</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleExportReport('pdf')}
              className="flex-1 sm:flex-none"
            >
              <Download className="h-4 w-4 mr-2" />
              PDF
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleExportReport('excel')}
              className="flex-1 sm:flex-none"
            >
              <Download className="h-4 w-4 mr-2" />
              Excel
            </Button>
          </div>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4 lg:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-blue-600">{metrics.patients.total}</p>
                <p className="text-xs lg:text-sm text-gray-600">Total Patients</p>
                <div className="flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 lg:h-4 lg:w-4 text-green-500 mr-1" />
                  <span className="text-xs text-green-600">+{metrics.patients.new} {getPeriodLabel().toLowerCase()}</span>
                </div>
              </div>
              <Users className="h-8 w-8 lg:h-10 lg:w-10 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4 lg:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-green-600">{metrics.appointments.total}</p>
                <p className="text-xs lg:text-sm text-gray-600">Appointments</p>
                <div className="flex items-center mt-1">
                  <span className="text-xs text-blue-600">{metrics.appointments.completed} completed</span>
                </div>
              </div>
              <Calendar className="h-8 w-8 lg:h-10 lg:w-10 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4 lg:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-purple-600">₹{metrics.revenue.total.toLocaleString()}</p>
                <p className="text-xs lg:text-sm text-gray-600">Total Revenue</p>
                <div className="flex items-center mt-1">
                  <span className="text-xs text-green-600">₹{metrics.revenue.paid.toLocaleString()} collected</span>
                </div>
              </div>
              <DollarSign className="h-8 w-8 lg:h-10 lg:w-10 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4 lg:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-orange-600">{Object.keys(metrics.treatments).length}</p>
                <p className="text-xs lg:text-sm text-gray-600">Treatment Types</p>
                <div className="flex items-center mt-1">
                  <span className="text-xs text-blue-600">{getPeriodLabel()}</span>
                </div>
              </div>
              <BarChart3 className="h-8 w-8 lg:h-10 lg:w-10 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Reports */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
        {/* Patient Analytics */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base lg:text-lg flex items-center">
              <Users className="h-4 w-4 lg:h-5 lg:w-5 mr-2" />
              Patient Analytics - {getPeriodLabel()}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span className="font-medium text-sm lg:text-base">Total Patients</span>
                <div className="text-right">
                  <Badge variant="outline" className="mr-2">{metrics.patients.total}</Badge>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => navigate('/patients')}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="font-medium text-sm lg:text-base">Active Patients</span>
                <div className="text-right">
                  <Badge variant="default" className="mr-2">{metrics.patients.active}</Badge>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => navigate('/patients')}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                <span className="font-medium text-sm lg:text-base">New Patients ({getPeriodLabel()})</span>
                <div className="text-right">
                  <Badge variant="secondary" className="mr-2">{metrics.patients.new}</Badge>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => navigate('/patients')}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Appointment Analytics */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base lg:text-lg flex items-center">
              <Calendar className="h-4 w-4 lg:h-5 lg:w-5 mr-2" />
              Appointment Analytics - {getPeriodLabel()}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span className="font-medium text-sm lg:text-base">Total Appointments</span>
                <div className="text-right">
                  <Badge variant="outline" className="mr-2">{metrics.appointments.total}</Badge>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => navigate('/appointments')}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="font-medium text-sm lg:text-base">Completed</span>
                <div className="text-right">
                  <Badge variant="default" className="mr-2">{metrics.appointments.completed}</Badge>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => navigate('/appointments')}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                <span className="font-medium text-sm lg:text-base">Confirmed</span>
                <div className="text-right">
                  <Badge variant="secondary" className="mr-2">{metrics.appointments.confirmed}</Badge>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => navigate('/appointments')}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                <span className="font-medium text-sm lg:text-base">Cancelled</span>
                <div className="text-right">
                  <Badge variant="destructive" className="mr-2">{metrics.appointments.cancelled}</Badge>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => navigate('/appointments')}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Revenue Analytics */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base lg:text-lg flex items-center">
              <DollarSign className="h-4 w-4 lg:h-5 lg:w-5 mr-2" />
              Revenue Analytics - {getPeriodLabel()}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span className="font-medium text-sm lg:text-base">Total Revenue</span>
                <div className="text-right">
                  <Badge variant="outline" className="mr-2">₹{metrics.revenue.total.toLocaleString()}</Badge>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => navigate('/billing')}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="font-medium text-sm lg:text-base">Collected Amount</span>
                <div className="text-right">
                  <Badge variant="default" className="mr-2">₹{metrics.revenue.paid.toLocaleString()}</Badge>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => navigate('/billing')}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                <span className="font-medium text-sm lg:text-base">Pending Amount</span>
                <div className="text-right">
                  <Badge variant="destructive" className="mr-2">₹{metrics.revenue.pending.toLocaleString()}</Badge>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => navigate('/billing')}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="pt-2">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>Collection Rate</span>
                  <span>{metrics.revenue.total > 0 ? Math.round((metrics.revenue.paid / metrics.revenue.total) * 100) : 0}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-500 h-2 rounded-full transition-all duration-300" 
                    style={{ 
                      width: `${metrics.revenue.total > 0 ? Math.round((metrics.revenue.paid / metrics.revenue.total) * 100) : 0}%` 
                    }}
                  ></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Treatment Analytics */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base lg:text-lg flex items-center">
              <FileText className="h-4 w-4 lg:h-5 lg:w-5 mr-2" />
              Treatment Analytics - {getPeriodLabel()}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.keys(metrics.treatments).length === 0 ? (
                <p className="text-sm text-gray-500 text-center py-4">No treatments recorded yet</p>
              ) : (
                Object.entries(metrics.treatments)
                  .sort(([,a], [,b]) => b - a)
                  .slice(0, 5)
                  .map(([treatment, count]) => (
                    <div key={treatment} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium text-sm lg:text-base capitalize">{treatment}</span>
                      <Badge variant="outline">{count} procedures</Badge>
                    </div>
                  ))
              )}
              {Object.keys(metrics.treatments).length > 5 && (
                <div className="text-center">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => navigate('/appointments')}
                  >
                    View All Treatments
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Export Summary */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base lg:text-lg">Report Summary - {getPeriodLabel()}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-center">
            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="text-2xl font-bold text-blue-600">{metrics.patients.total}</p>
              <p className="text-sm text-gray-600">Total Patients</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <p className="text-2xl font-bold text-green-600">{metrics.appointments.total}</p>
              <p className="text-sm text-gray-600">Total Appointments</p>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg">
              <p className="text-2xl font-bold text-purple-600">₹{metrics.revenue.total.toLocaleString()}</p>
              <p className="text-sm text-gray-600">Total Revenue</p>
            </div>
            <div className="p-4 bg-orange-50 rounded-lg">
              <p className="text-2xl font-bold text-orange-600">{Object.keys(metrics.treatments).length}</p>
              <p className="text-sm text-gray-600">Treatment Types</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Reports;