
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';
import {
  User,
  Mail,
  Phone,
  Building,
  Palette,
  Monitor,
  Sun,
  Moon,
  Save,
  Settings as SettingsIcon,
  Shield,
  Globe,
  Lock
} from 'lucide-react';

const Settings = () => {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [isDarkMode, setIsDarkMode] = useState(() => {
    return document.documentElement.classList.contains('dark');
  });
  
  const [adminInfo, setAdminInfo] = useState({
    name: 'Dr. John Smith',
    email: 'admin@drsnehadentalclinic.com',
    phone: '+1 (555) 123-4567',
    clinic: 'Sneha Dental Care',
    address: '123 Health Street, Medical City, MC 12345',
    license: 'DEN-2024-001',
    specialization: 'General Dentistry'
  });

  const [loginInfo, setLoginInfo] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const handleThemeToggle = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    
    if (newTheme) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    toast({
      title: "Theme Updated",
      description: `Switched to ${newTheme ? 'Dark' : 'Light'} mode`,
    });
  };

  const handleAdminInfoSave = () => {
    toast({
      title: "Admin Information Updated",
      description: "Your profile information has been saved successfully.",
    });
  };

  const handlePasswordChange = () => {
    if (loginInfo.newPassword !== loginInfo.confirmPassword) {
      toast({
        title: "Password Mismatch",
        description: "New password and confirmation do not match.",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Password Updated",
      description: "Your password has been changed successfully.",
    });
    
    setLoginInfo({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setAdminInfo(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleLoginInputChange = (field: string, value: string) => {
    setLoginInfo(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="min-h-screen bg-background mobile-padding py-4 sm:py-6 animate-fade-in">
      <div className="max-w-6xl mx-auto space-y-4 sm:space-y-6">
        {/* Header with slide-in animation */}
        <div className="flex items-center space-x-3 mb-6 sm:mb-8 animate-slide-up">
          <div className="p-2 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg shadow-lg transform transition-transform duration-300 hover:scale-110 hover:rotate-3">
            <SettingsIcon className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
          </div>
          <div>
            <h1 className="mobile-title font-bold text-foreground">Settings</h1>
            <p className="text-muted-foreground mobile-text">Manage your system preferences and account information</p>
          </div>
        </div>

        <div className={`grid grid-cols-1 ${isMobile ? 'gap-4' : 'lg:grid-cols-3 gap-6'}`}>
          {/* Admin Information with staggered animation */}
          <div className={`${isMobile ? 'order-1' : 'lg:col-span-2'} animate-fade-in`} style={{ animationDelay: '0.1s' }}>
            <Card className="shadow-lg hover:shadow-xl transition-all duration-500 transform hover:-translate-y-1 bg-card/95 backdrop-blur-sm border border-border/50">
              <CardHeader className="bg-gradient-to-r from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20 transition-all duration-300">
                <CardTitle className="flex items-center space-x-2">
                  <User className="h-4 w-4 sm:h-5 sm:w-5 text-amber-600 transition-transform duration-300 hover:scale-110" />
                  <span className="mobile-text">Admin Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 space-y-4 sm:space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2 transform transition-all duration-300 hover:scale-[1.02]">
                    <Label htmlFor="name" className="text-sm font-medium">Full Name</Label>
                    <Input
                      id="name"
                      value={adminInfo.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      className="transition-all duration-300 focus:ring-2 focus:ring-amber-500 focus:scale-[1.02] bg-background/80 backdrop-blur-sm"
                    />
                  </div>
                  <div className="space-y-2 transform transition-all duration-300 hover:scale-[1.02]">
                    <Label htmlFor="email" className="text-sm font-medium">Email Address</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground transition-colors duration-300" />
                      <Input
                        id="email"
                        type="email"
                        value={adminInfo.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="pl-10 transition-all duration-300 focus:ring-2 focus:ring-amber-500 focus:scale-[1.02] bg-background/80 backdrop-blur-sm"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2 transform transition-all duration-300 hover:scale-[1.02]">
                    <Label htmlFor="phone" className="text-sm font-medium">Phone Number</Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground transition-colors duration-300" />
                      <Input
                        id="phone"
                        value={adminInfo.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        className="pl-10 transition-all duration-300 focus:ring-2 focus:ring-amber-500 focus:scale-[1.02] bg-background/80 backdrop-blur-sm"
                      />
                    </div>
                  </div>
                  <div className="space-y-2 transform transition-all duration-300 hover:scale-[1.02]">
                    <Label htmlFor="clinic" className="text-sm font-medium">Clinic Name</Label>
                    <div className="relative">
                      <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground transition-colors duration-300" />
                      <Input
                        id="clinic"
                        value={adminInfo.clinic}
                        onChange={(e) => handleInputChange('clinic', e.target.value)}
                        className="pl-10 transition-all duration-300 focus:ring-2 focus:ring-amber-500 focus:scale-[1.02] bg-background/80 backdrop-blur-sm"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2 transform transition-all duration-300 hover:scale-[1.02]">
                  <Label htmlFor="address" className="text-sm font-medium">Clinic Address</Label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-3 h-4 w-4 text-muted-foreground transition-colors duration-300" />
                    <textarea
                      id="address"
                      value={adminInfo.address}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                      rows={3}
                      className="w-full pl-10 p-3 border border-input rounded-md bg-background/80 backdrop-blur-sm text-foreground transition-all duration-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 resize-none focus:scale-[1.02]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2 transform transition-all duration-300 hover:scale-[1.02]">
                    <Label htmlFor="license" className="text-sm font-medium">License Number</Label>
                    <div className="relative">
                      <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground transition-colors duration-300" />
                      <Input
                        id="license"
                        value={adminInfo.license}
                        onChange={(e) => handleInputChange('license', e.target.value)}
                        className="pl-10 transition-all duration-300 focus:ring-2 focus:ring-amber-500 focus:scale-[1.02] bg-background/80 backdrop-blur-sm"
                      />
                    </div>
                  </div>
                  <div className="space-y-2 transform transition-all duration-300 hover:scale-[1.02]">
                    <Label htmlFor="specialization" className="text-sm font-medium">Specialization</Label>
                    <Input
                      id="specialization"
                      value={adminInfo.specialization}
                      onChange={(e) => handleInputChange('specialization', e.target.value)}
                      className="transition-all duration-300 focus:ring-2 focus:ring-amber-500 focus:scale-[1.02] bg-background/80 backdrop-blur-sm"
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <Button
                    onClick={handleAdminInfoSave}
                    className="w-full sm:w-auto bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover:-translate-y-1 touch-target"
                  >
                    <Save className="h-4 w-4 mr-2 transition-transform duration-300 group-hover:rotate-12" />
                    Save Changes
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Login Information with animation delay */}
            <Card className="shadow-lg hover:shadow-xl transition-all duration-500 transform hover:-translate-y-1 bg-card/95 backdrop-blur-sm border border-border/50 mt-4 sm:mt-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
              <CardHeader className="bg-gradient-to-r from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20 transition-all duration-300">
                <CardTitle className="flex items-center space-x-2">
                  <Lock className="h-4 w-4 sm:h-5 sm:w-5 text-amber-600 transition-transform duration-300 hover:scale-110" />
                  <span className="mobile-text">Login Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 space-y-4">
                <div className="space-y-2 transform transition-all duration-300 hover:scale-[1.02]">
                  <Label htmlFor="currentPassword" className="text-sm font-medium">Current Password</Label>
                  <Input
                    id="currentPassword"
                    type="password"
                    value={loginInfo.currentPassword}
                    onChange={(e) => handleLoginInputChange('currentPassword', e.target.value)}
                    className="transition-all duration-300 focus:ring-2 focus:ring-amber-500 focus:scale-[1.02] bg-background/80 backdrop-blur-sm"
                  />
                </div>
                <div className="space-y-2 transform transition-all duration-300 hover:scale-[1.02]">
                  <Label htmlFor="newPassword" className="text-sm font-medium">New Password</Label>
                  <Input
                    id="newPassword"
                    type="password"
                    value={loginInfo.newPassword}
                    onChange={(e) => handleLoginInputChange('newPassword', e.target.value)}
                    className="transition-all duration-300 focus:ring-2 focus:ring-amber-500 focus:scale-[1.02] bg-background/80 backdrop-blur-sm"
                  />
                </div>
                <div className="space-y-2 transform transition-all duration-300 hover:scale-[1.02]">
                  <Label htmlFor="confirmPassword" className="text-sm font-medium">Confirm New Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={loginInfo.confirmPassword}
                    onChange={(e) => handleLoginInputChange('confirmPassword', e.target.value)}
                    className="transition-all duration-300 focus:ring-2 focus:ring-amber-500 focus:scale-[1.02] bg-background/80 backdrop-blur-sm"
                  />
                </div>
                <Button
                  onClick={handlePasswordChange}
                  className="w-full sm:w-auto bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover:-translate-y-1 touch-target"
                >
                  <Save className="h-4 w-4 mr-2 transition-transform duration-300 group-hover:rotate-12" />
                  Change Password
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Appearance Settings with animation delay */}
          <div className={`space-y-4 sm:space-y-6 ${isMobile ? 'order-2' : ''} animate-fade-in`} style={{ animationDelay: '0.3s' }}>
            <Card className="shadow-lg hover:shadow-xl transition-all duration-500 transform hover:-translate-y-1 bg-card/95 backdrop-blur-sm border border-border/50">
              <CardHeader className="bg-gradient-to-r from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20 transition-all duration-300">
                <CardTitle className="flex items-center space-x-2">
                  <Palette className="h-4 w-4 sm:h-5 sm:w-5 text-amber-600 transition-transform duration-300 hover:scale-110" />
                  <span className="mobile-text">Appearance</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 space-y-4 sm:space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30 transition-all duration-300 hover:bg-muted/50 hover:scale-[1.02]">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg transition-all duration-300 ${isDarkMode ? 'bg-amber-900/20 rotate-180' : 'bg-amber-100'}`}>
                        <Monitor className="h-4 w-4 sm:h-5 sm:w-5 text-amber-600 transition-transform duration-300" />
                      </div>
                      <div>
                        <p className="font-medium mobile-text">Theme Mode</p>
                        <p className="text-xs sm:text-sm text-muted-foreground">Switch between light and dark mode</p>
                      </div>
                    </div>
                    <Switch
                      checked={isDarkMode}
                      onCheckedChange={handleThemeToggle}
                      className="data-[state=checked]:bg-amber-600 transition-all duration-300 scale-110 hover:scale-125"
                    />
                  </div>

                  <Separator className="transition-opacity duration-300" />

                  <div className="space-y-3 transition-all duration-300">
                    <p className="text-sm font-medium">Theme Preview</p>
                    <div className="grid grid-cols-2 gap-3">
                      <div className={`p-3 rounded-lg border-2 transition-all duration-500 transform hover:scale-105 ${!isDarkMode ? 'border-amber-400 bg-amber-50 dark:bg-amber-900/20 shadow-md' : 'border-muted bg-muted/30'}`}>
                        <div className="flex items-center space-x-2 mb-2">
                          <Sun className={`h-4 w-4 text-amber-600 transition-all duration-300 ${!isDarkMode ? 'rotate-180' : ''}`} />
                          <span className="text-xs sm:text-sm font-medium">Light Mode</span>
                        </div>
                        <div className="space-y-1">
                          <div className="h-2 bg-amber-200 rounded transition-all duration-300"></div>
                          <div className="h-2 bg-amber-100 rounded w-3/4 transition-all duration-300"></div>
                        </div>
                      </div>
                      <div className={`p-3 rounded-lg border-2 transition-all duration-500 transform hover:scale-105 ${isDarkMode ? 'border-amber-400 bg-amber-900/20 shadow-md' : 'border-muted bg-muted/30'}`}>
                        <div className="flex items-center space-x-2 mb-2">
                          <Moon className={`h-4 w-4 text-amber-600 transition-all duration-300 ${isDarkMode ? 'rotate-12' : ''}`} />
                          <span className="text-xs sm:text-sm font-medium">Dark Mode</span>
                        </div>
                        <div className="space-y-1">
                          <div className="h-2 bg-amber-600 rounded transition-all duration-300"></div>
                          <div className="h-2 bg-amber-700 rounded w-3/4 transition-all duration-300"></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Separator className="transition-opacity duration-300" />

                  <div className="space-y-3 transition-all duration-300 hover:scale-[1.02]">
                    <p className="text-sm font-medium">Color Scheme</p>
                    <div className="flex items-center space-x-3 p-3 rounded-lg bg-muted/30 transition-all duration-300 hover:bg-muted/50">
                      <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-amber-400 to-amber-600 rounded-full shadow-lg transition-transform duration-300 hover:scale-110 hover:rotate-45"></div>
                      <div>
                        <p className="text-xs sm:text-sm font-medium">Gold & {isDarkMode ? 'Black' : 'White'}</p>
                        <p className="text-xs text-muted-foreground">Primary color scheme</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* System Info with animation delay */}
            <Card className="shadow-lg hover:shadow-xl transition-all duration-500 transform hover:-translate-y-1 bg-card/95 backdrop-blur-sm border border-border/50 animate-fade-in" style={{ animationDelay: '0.4s' }}>
              <CardHeader className="bg-gradient-to-r from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20 transition-all duration-300">
                <CardTitle className="flex items-center space-x-2">
                  <Monitor className="h-4 w-4 sm:h-5 sm:w-5 text-amber-600 transition-transform duration-300 hover:scale-110" />
                  <span className="mobile-text">System Info</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 sm:p-6">
                <div className="space-y-3 text-xs sm:text-sm">
                  <div className="flex justify-between p-2 rounded-lg transition-all duration-300 hover:bg-muted/30 hover:scale-[1.02]">
                    <span className="text-muted-foreground">Version</span>
                    <span className="font-medium">2.1.0</span>
                  </div>
                  <div className="flex justify-between p-2 rounded-lg transition-all duration-300 hover:bg-muted/30 hover:scale-[1.02]">
                    <span className="text-muted-foreground">Last Updated</span>
                    <span className="font-medium">{new Date().toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between p-2 rounded-lg transition-all duration-300 hover:bg-muted/30 hover:scale-[1.02]">
                    <span className="text-muted-foreground">Database</span>
                    <span className="font-medium text-green-600 flex items-center space-x-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span>Connected</span>
                    </span>
                  </div>
                  <div className="flex justify-between p-2 rounded-lg transition-all duration-300 hover:bg-muted/30 hover:scale-[1.02]">
                    <span className="text-muted-foreground">Backup Status</span>
                    <span className="font-medium text-green-600 flex items-center space-x-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span>Up to date</span>
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
