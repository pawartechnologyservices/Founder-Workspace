export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'doctor' | 'receptionist' | 'patient';
  phone?: string;
  specialization?: string; // for doctors
  department?: string;
}

export interface Patient {
  id: string;
  name: string;
  email: string;
  phone: string;
  dateOfBirth: Date;
  age?: number; // calculated from dateOfBirth
  gender: 'male' | 'female' | 'other';
  address: string;
  emergencyContact: string;
  medicalHistory: string[];
  dentalHistory: string[];
  allergies: string[];
  status: 'active' | 'inactive' | 'new'; // added status field
  lastVisit?: Date; // added lastVisit field
  appointments?: string[]; // added appointments field for appointment IDs
  createdAt: Date;
  updatedAt: Date;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  patientPhone?: string; // added patientPhone field
  doctorId: string;
  doctorName: string;
  date: Date;
  time: string;
  duration: number; // in minutes
  type: 'consultation' | 'cleaning' | 'surgery' | 'checkup' | 'emergency';
  status: 'scheduled' | 'confirmed' | 'completed' | 'cancelled' | 'no-show' | 'pending'; // added 'pending' status
  notes?: string;
  treatmentPlan?: string;
  createdAt: Date;
}

export interface Treatment {
  id: string;
  patientId: string;
  doctorId: string;
  appointmentId: string;
  date: Date;
  procedure: string;
  diagnosis: string;
  treatment: string;
  medications: Medication[];
  cost: number;
  status: 'planned' | 'ongoing' | 'completed';
  notes: string;
  attachments: string[]; // file URLs
}

export interface Medication {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  instructions: string;
}

export interface Bill {
  id: string;
  patientId: string;
  patientName: string;
  treatments: Treatment[];
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  status: 'pending' | 'paid' | 'partially_paid' | 'overdue';
  paymentMethod?: 'cash' | 'card' | 'upi' | 'insurance';
  paidAmount: number;
  createdAt: Date;
  dueDate: Date;
}

export interface InventoryItem {
  id: string;
  name: string;
  category: 'instruments' | 'medicines' | 'supplies' | 'equipment';
  currentStock: number;
  minStock: number;
  maxStock: number;
  unit: string;
  costPerUnit: number;
  supplier: string;
  expiryDate?: Date;
  lastRestocked: Date;
  status: 'in_stock' | 'low_stock' | 'out_of_stock' | 'expired';
}

export interface EmergencyContact {
  id: string;
  name: string;
  role: string;
  phone: string;
  email?: string;
  isOnCall: boolean;
  specialty?: string;
}
